
const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');

const app = express();
const port = 3000;

// Database setup
const pool = new Pool({
  user: 'username',
  host: 'localhost',
  database: 'mydatabase',
  password: 'password',
  port: 5432,
});

app.use(bodyParser.json());
app.use(express.static('public'));  // Serve static files from the public directory

// [INSERT THE API ENDPOINTS CODE HERE]

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
});
